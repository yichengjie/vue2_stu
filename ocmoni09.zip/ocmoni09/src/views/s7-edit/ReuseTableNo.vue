<template>
    <span class="table_reuse">
        <label class ="text-info">复用表号:</label>
        <span style="position: relative;">
            <input type="text" class="common_input" id="autocomplete" style="width: 100px"/>
            <i class="glyphicon glyphicon-search gray" style="position: absolute;right: 10px"></i>
        </span>

        <span class ="text-danger myhand ng-hide">自定义表格</span>
    </span>
</template>