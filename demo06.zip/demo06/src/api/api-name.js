export const QUERYDB_API = "queryDbApi" ;
export const BATCHIMPORT_API  = "batchImportApi" ;
export const BATCHABORT_API = "batchAbortApi" ;
export const BATCHPUBLISH_API = "batchPublishApi" ;
export const BATCHDELETE_API = "batchDeleteApi" ;